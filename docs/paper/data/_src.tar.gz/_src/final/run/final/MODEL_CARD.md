# Model card: BES-100M-A20M, export of run `main16`

Written by `bes/export.py` (export format 1) on 2026-11-24 01:49:37 UTC from the files of this run and measurements made during the export. Nothing here is a projection; a fact the run did not record is marked as missing.

## What this is

A looped transformer: d_model 768, 2 shared blocks applied 8 times, 6 heads of 128, feed-forward width 3072, vocabulary 8192, context 2048 tokens (`docs/PLAN.md`). Feature paths on: registers, candidate-tape input features (n-gram count heads), candidate-tape masses in the output law, calibrated attention sinks. Switched off: the confidence channel, structural clocks. A written library (Simple English Wikipedia passages and question-answer pairs) ships with it behind a calibrated retrieval gate, on by default. Replies are decoded with K = 6 particles steered by exact potentials and chosen by a satisficing rule.

- checkpoint: `/content/runs/main16/train/ckpt/ckpt-000005-step-000005075` (step 5075, train weights)
- configuration hash 0a7e9b33372a07ee; configuration file `configs/final.py`, overrides `['model.table_grad=take', 'run.bench_plans=reduced', 'run.post_minutes=critic=0,buffer=20', 'run.post_reserve_hours=3.6667', 'optim.micro_seqs=16', 'run.deadline_hours=21.328333333333333', 'model.attn_impl=splash', 'model.remat=true', 'optim.micro_seqs=16', 'model.table_grad=take']`
- code commit 98598c212bca1cfd7d4108d4eba43f0cfba91f96 (uncommitted changes: False)

## Stored weights (at most 16 bits per number)

| format | leaves | numbers | largest relative L2 error of a leaf |
|---|---|---|---|
| float16 | 59 | 34,531,720 | 0.000309 |
| bfloat16 | 0 | 0 | 0.000000 |
| total | 59 | 34,531,720 | |

Each leaf is stored in the format with the smaller measured relative error (`weights.json` lists both errors per leaf); the loader restores float32.

### Held-out check

Mean cross-entropy on 43,138 held-out tokens (float32 activations, dense attention, highest matmul precision): float32 weights 2.47806 nats, 16-bit weights 2.47808 nats, difference +0.000028 nats (tolerance 0.002): **passed**.

| domain | weighted tokens | float32 | 16-bit | difference |
|---|---|---|---|---|
| chat | 15,690 | 1.76315 | 1.76319 | +0.000036 |
| proxy | 11,094 | 2.78869 | 2.78875 | +0.000064 |
| web | 16,354 | 2.95321 | 2.95321 | -0.000004 |

Held-out data:
- chat: HuggingFaceTB/smol-smoltalk/data/test-00000-of-00001.parquet, 16 rows of 1024 tokens (the test split; the registry reads the train files only)
- proxy: bes/eval/proxy/prompts.jsonl (user turns), 12 rows of 1024 tokens
- web: karpathy/climbmix-400b-shuffle/shard_00997.parquet, 16 rows of 1024 tokens (beyond the run's ClimbMix download cap (files are taken in listing order up to the cap))

## Accounting (`bes.budget`, real library sizes)

| row | stored numbers | numbers read per generated token |
|---|---|---|
| core | 14,118,912 | 14,118,912 |
| head | 4,587,520 | 4,587,520 |
| small | 306,776 | 306,776 |
| emb | 6,291,456 | 768 |
| ve | 8,388,608 | 1,024 |
| gain | 0 | 0 |
| page | 0 | 0 |
| tables | 838,448 | 18,736 |
| library | 40,268,392 | 112,595 |
| index | 23,499,999 | 132,628 |
| **total** | **98,300,111** | **19,278,959** |

Caps 100,000,000 stored / 20,000,000 read per token: within both. The per-token column is the standard convention of `docs/ACCOUNTING.md`: every dense leaf, one row per lookup read, and the worst-case read of one library retrieval charged to the step that retrieves.

Library: 535,296 wiki passages and 154,989 question-answer entries; 63,768,391 stored numbers (text blocks, directory and titles 34,846,433, BM25 index 23,499,999, title look-up 990,260, qa layer 4,431,649, gate 50); worst-case read of one retrieval 245,223.

The export's library holds exactly these tables: 29 arrays of 63,768,370 numbers plus 21 header numbers in their JSON files = 63,768,391, at most 16 bits per counted number (the 32-bit tables `gate_coef.npy`, `index_coarse.npy`, `index_postings.npy`, `pack_block_crc.npy`, `pack_block_first.npy`, `pack_block_off.npy`, `pack_block_raw.npy`, `pack_tblock_crc.npy`, `pack_tblock_off.npy`, `pack_tblock_raw.npy`, `pack_title_first.npy`, `qa_block_crc.npy`, `qa_block_first.npy`, `qa_block_off.npy`, `qa_block_raw.npy`, `qa_coarse.npy`, `qa_post.npy`, `titlekey_hash.npy`, `titlekey_ref.npy` count two numbers per element), plus the attribution text. Left out (not counted, never read by the model): `build_settings.json`, `qa_clean.json`.

## Read-set audit (`bes.readset.ReadLogger`)

Distinct stored numbers read for each generated token on held-out sequences with their real exact-layer features. *step*: the standard convention (given the cache); *strict*: the union over the visible context window.

| probe | positions | distinct tokens | step mean | step max | strict at the end | strict max |
|---|---|---|---|---|---|---|
| web (held-out record) | 2048 | 883 | 18,830,305 | 18,832,105 | 20,565,666 | 20,565,666 |
| chat (held-out record) | 1480 | 560 | 18,830,452 | 18,832,492 | 19,911,000 | 19,911,455 |
- web (held-out record), window of 1024 positions: strict 19,837,720 (512 distinct tokens)
- web (held-out record), window of 2048 positions: strict 20,565,666 (883 distinct tokens)
- chat (held-out record), window of 1024 positions: strict 19,632,350 (410 distinct tokens)

Library retrievals over 500 proxy-prompt turns: 11 returned a passage; numbers read per retrieval mean 10343, max 105,826 (bound 245,223). Largest step count plus the largest measured retrieval: 18,938,318.
The critic head is not read (the decoder does not use it).

## Training run

- budget 21.33 h of wall time from 2026-11-23 17:34 UTC; 4 resumes
- devices: ['TPU v6 lite'] (jax 0.11.2, backend tpu)
- trained 1,330,905,088 tokens in 5,077 optimiser steps; 1.67 h in the step loop; set-up 4 s, checkpoints 2 s, lost to restarts and rollbacks 0 s; 0 restarts, 0 rollbacks
- execution plan splash-remat1-ms16-take (208,837 tokens/s expected), horizon 1.312e+10 tokens
- fallback ladder rung 0 (full configuration)
- canary: parity True, determinism True, safe run True, full run True

| stage | status | planned | used | note |
|---|---|---|---|---|
| preflight | finished | 3.0 min | 0 s |  |
| background | finished | 1.0 min | 0 s |  |
| benchmark | finished | 15.0 min | 11.6 min |  |
| train | failed | 17.34 h | 2.21 h | RuntimeError: the training journal used 409 shards, 1 of them are not on this machine (e.g. synth_rag/0) and the tokenis interrupted 1x |
| sample | pending | - | 0 s |  |
| critic | pending | - | 0 s |  |
| prefopt | pending | - | 0 s |  |
| select | pending | - | 0 s |  |
| judge | pending | - | 0 s |  |
| export | pending | - | 0 s |  |

## Post-training and evaluation

- preference optimisation: no record
- decoding choice: no record (the run's own `DecodeCfg` is the default)
- judged comparison: no record

Reports copied into `reports/`: `reports/manifest.json`, `reports/stages.json`, `reports/train_ledger.json`, `reports/train_run.json`

## Disclosures (`docs/PLAN.md` section 2)

- **Library**: shipped and on by default; frozen and hashed before any prompt (digest 411f6388aaa61051...), offline, counted in the stored numbers above; no decode selection recorded
- **Inference-time compute**: K = 6 samples of this model per reply (particle decoding with exact potentials, then satisficing selection); the decode selection compares K = 1 when K > 1
- **External models**: scoring only: the judge `qwen3-4b-2507` rates blinded pairs and the opponents (falcon=recommended mobilellm=recommended mobilellm=neutral) are only compared against; no training step reads another model's logits (no distillation); run.use_external_models = True
- **Preference data**: no preference optimisation record

## Data, licences and attribution

| training source | dataset | licence (dataset card) | non-permissive | tokenised in this run |
|---|---|---|---|---|
| climbmix | karpathy/climbmix-400b-shuffle | card: mit; upstream nvidia/Nemotron-ClimbMix: cc-by-nc-4.0 | True | True |
| smol_smoltalk | HuggingFaceTB/smol-smoltalk | apache-2.0 | False | True |
| smoltalk_magpie_ultra | HuggingFaceTB/smoltalk | apache-2.0 (card text; the YAML header has no licence field) | False | True |
| tulu3_sft | allenai/tulu-3-sft-mixture | odc-by-1.0 (subsets carry their own licences; the CC BY-NC No Robots subset is excluded) | False | True |
| synth | PleIAs/SYNTH | cc-by-4.0 (card); seed text CC BY-SA 4.0 / CC0 (column seed_license) | False | True |
| ultrachat | HuggingFaceH4/ultrachat_200k | mit | False | True |
| smoltalk_constraints | HuggingFaceTB/smoltalk | apache-2.0 (card text; the YAML header has no licence field) | False | True |
| smoltalk_rewrite | HuggingFaceTB/smoltalk | apache-2.0 (card text; the YAML header has no licence field) | False | True |
| smoltalk_summarize | HuggingFaceTB/smoltalk | apache-2.0 (card text; the YAML header has no licence field) | False | True |
| smoltalk_everyday | HuggingFaceTB/smoltalk | apache-2.0 (card text; the YAML header has no licence field) | False | True |
| smoltalk_systemchats | HuggingFaceTB/smoltalk | apache-2.0 (card text; the YAML header has no licence field) | False | True |
| synth_rag | PleIAs/SYNTH | cc-by-4.0 (card); seed text CC BY-SA 4.0 / CC0 (column seed_license) | False | True |
| glaive_rag | glaiveai/RAG-v1 | apache-2.0 | False | True |
| rag_instruct | FreedomIntelligence/RAG-Instruct | apache-2.0 | False | True |
| squad_v2 | rajpurkar/squad_v2 | cc-by-sa-4.0 | False | True |
| hotpot_qa | hotpotqa/hotpot_qa | cc-by-sa-4.0 | False | True |
| dolly | databricks/databricks-dolly-15k | cc-by-sa-3.0 | False | True |
| neural_bridge_rag | neural-bridge/rag-dataset-12000 | apache-2.0 (the card also asks users to abide by the terms of use of the web corpus it was drawn from) | False | True |
| orca_math | microsoft/orca-math-word-problems-200k | mit | False | True |
| gsm8k | openai/gsm8k | mit | False | True |
| fineweb_edu | karpathy/fineweb-edu-100b-shuffle | odc-by | False | True |
| simplewiki | wikimedia/wikipedia | cc-by-sa-3.0 and gfdl (card) | False | True |
| ultrafeedback | HuggingFaceH4/ultrafeedback_binarized | mit | False | True |

Caveats per source (synthetic outputs of third-party models, upstream terms): `docs/DATA_SOURCES.md` section 4.

Tokenizer trained on: karpathy/climbmix-400b-shuffle ['shard_00000.parquet', 'shard_00001.parquet']; HuggingFaceTB/smol-smoltalk ['data/train-00000-of-00004.parquet']; wikimedia/wikipedia ['20231101.simple/train-00000-of-00001.parquet']

Library (copy, digest 411f6388aaa61051...): Simple English Wikipedia text (CC BY-SA 3.0 / GFDL) and the question-answer pairs below; per-article and per-entry attribution in `ATTRIBUTION.md`, `ATTRIBUTION.tsv` and `ATTRIBUTION_QA.tsv` of the library directory (copied next to this card as `LIBRARY_ATTRIBUTION.md`).

| question-answer source (stored in the library) | dataset | config / split | licence (dataset card) | permissive | entries |
|---|---|---|---|---|---|
| nq_open_train | google-research-datasets/nq_open | nq_open / train | cc-by-sa-3.0 (card: 'All of the Natural Questions data is released under CC BY-SA 3.0') | True | 77,911 |
| trivia_qa_train | mandarjoshi/trivia_qa | rc.nocontext / train | unknown (card YAML 'unknown'; card text: 'The University of Washington does not own the copyright of the questions and documents included in TriviaQA') | False | 73,568 |
| web_questions_train | stanfordnlp/web_questions | default / train | unknown (card YAML 'unknown'; licensing section 'More Information Needed') | False | 3,510 |

Build settings recorded with the library: permissive only False, question-answer sources asked for ['nq_open_train', 'trivia_qa_train', 'web_questions_train'], tokenizer sha256 15d5b99b37e14203...

Models used for evaluation only (never trained on, never shipped):
- falcon (opponent): tiiuae/Falcon-H1-Tiny-90M-Instruct, file tiiuae/Falcon-H1-Tiny-90M-Instruct-GGUF/Falcon-H1-Tiny-90M-Instruct-Q8_0.gguf, licence Falcon-LLM License
- mobilellm (opponent): facebook/MobileLLM-R1.5-140M (gated), file sasa2000/MobileLLM-R1.5-140M-Q8_0-GGUF/mobilellm-r1.5-140m-q8_0.gguf, licence FAIR Noncommercial Research License
- qwen3-4b-2507 (judge): Qwen/Qwen3-4B-Instruct-2507, file unsloth/Qwen3-4B-Instruct-2507-GGUF/Qwen3-4B-Instruct-2507-Q4_K_M.gguf, licence Apache-2.0

## Files

SHA-256 of every file is in `SHA256SUMS` (`sha256sum -c SHA256SUMS` or `python scripts/export.py --verify <dir>`). Main files:

| file | bytes | sha256 |
|---|---|---|
| `weights16.npz` | 69,078,798 | `916b8d7f5548a077...` |
| `weights.json` | 16,459 | `d22fa18129814ba8...` |
| `config.json` | 5,174 | `ddb88f5430e0865c...` |
| `tokenizer/tokenizer.json` | 129,787 | `78a7392833c33f1e...` |

Load for inference: `from bes.export import load_export; m = load_export(dir)`; chat: `python scripts/chat.py --export <dir>`; blind arena: `python scripts/arena.py --export <dir>`.
